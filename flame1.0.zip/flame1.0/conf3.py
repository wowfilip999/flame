import pyautogui
pyautogui.click()