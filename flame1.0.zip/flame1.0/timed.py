import time
time.sleep(4)