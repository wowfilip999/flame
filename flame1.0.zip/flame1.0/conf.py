from tkinter import *
from tkinter import messagebox
messagebox.showwarning("!!! autoclick is hard to off", "when hold left button stop clicking for off autoclicker close window or terminal for remove message click warn button ")
